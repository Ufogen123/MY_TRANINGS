﻿// DZ_5.cpp - задача-1 : 

#include <iostream>
// Задача 1  Написать функцию которая выводит массив double чисел на экран. 
// Параметры функции это сам массив и его размер. Вызвать эту функцию из main.
using namespace std;
double print( size_t size, double arr[])
{
	for (size_t i = 0; i < size; i++)
	{
		cout << arr[i]<<"  ";
	}
	cout << endl;
	return 0.0f;
}

int main()
{
   const size_t size{ 10 };
   double array[size] = { 1.05f,3.22f,5.22f ,4.22f ,3.22f ,5.22f ,1.22f ,8.22f ,7.22f ,9.22f };
   print(size, array);
   return 0;
}



