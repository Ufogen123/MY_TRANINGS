﻿// DZ_6.cpp 

#include <iostream>
#include <math.h>
#include <cstdlib>
#include <fstream>
size_t size;
using namespace std;


//Задача 1. Выделить в памяти динамический одномерный массив типа int. 
//Размер массива запросить у пользователя. 
//Инициализировать его числами степенями двойки: 1, 2, 4, 8, 16, 32, 64, 128 ... 
//Вывести массив на экран. Не забыть освободить память. =) Разбить программу на функции.

    bool clear(int* ptr)                   //очистка
    {
    delete[] ptr;
    return true;
    }
    bool obiavlenie(size_t size)            //выделение памяти под массив
    {

    int* ptr = new int[size];              
    for (size_t i = 0; i < size; i++)           
    {
        ptr[i] = pow(2,i);
        cout << "polu4enniy massiv:  " << ptr[i] << endl;
                               //вызываем очистку
    }
    clear(ptr);
    return true;
    }
    /**/
    bool task_1()
    {
        size_t size;
        cout << "Input size array:  " << endl;
        cin >> size;
        obiavlenie(size);
        return true;
    }
    /**/
    //Задача 2.Динамически выделить матрицу 4х4 типа int.
        //Инициализировать ее псевдослучайными числами через функцию rand.
        //Вывести на экран.
        //Разбейте вашу программу на функции которые вызываются из main.
    //выделение памяти под массив
    
    bool clear_2(int** ptr2, int size)                   //очистка
    {
        for (size_t i = 0; i < size; i++)
        {
            delete[] ptr2[i];

        }
        delete[] ptr2;
        return true;
    }
    bool matrix(size_t size)            
    {

        int** ptr2 = new int*[size];
        for (size_t i = 0; i < size; i++)
        {
            ptr2[i] = new int[size];
            
        }
        for (size_t i = 0; i < size; i++)
        {
            
            for (size_t j = 0; j < size; j++)
            {
                ptr2[i][j] = rand()%100;
                cout  <<"  " << ptr2[i][j] << endl;

            }
            printf("\n");
        }
        

        clear_2(ptr2, size);
        return true;
    }
    /**/
    bool task_2()
    {
        size_t size;
        cout << "Input size array:  " << endl;
        cin >> size;
        matrix(size);
        return true;
    }
    /**/
    /*
    * Задача 3.Написать программу, которая создаст два текстовых файла (*.txt), 
    примерно по 50-100 символов в каждом (особого значения не имеет с каким именно содержимым). 
    Имена файлов запросить у польлзователя
    */
   static int A[50] = {0};
   static int B[100] = { 0 };
    bool task_3()
    {
        string stz;
        string stz2;
        cout << "filename_1:  " << endl;
        cin >> stz;
        cout << "filename_2:  " << endl;
        cin >> stz2;
        ofstream  fout;
        ofstream fout2;
        fout.open(stz+".txt");
        fout2.open(stz2 + ".txt");
        if (fout.is_open())
        {   

        fout << "massiv  " << A << endl;
        fout.close();
        }

        else if (fout2.is_open())
        {
            fout2 << "massiv  " << B << endl;
            fout2.close();
        }
        
        return true;
    }
    /**/
int main()
{
   // task_1();
   // task_2();
    task_3();
    return 0;
}

