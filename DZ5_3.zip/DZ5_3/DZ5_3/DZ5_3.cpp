﻿// DZ_5.cpp - задача-3 : 

#include <iostream>
#include <cstdlib>
/*Задача 3. Задать пустой целочисленный массив размером 8. 
Написать функцию, которая с помощью цикла заполнит его значениями 1 4 7 10 13 16 19 22. 
Вывести массив на экран.
*/
using namespace std;
int zapolnenie(int size, int *ptr)
{
	
	for (int i = 0; i < size; i++)
	{
		ptr[0] = 1;
		ptr[i]= ptr[0]+3*i;
		
		
		cout << "New vector is  " << ptr[i] << endl;
	}
	cout << endl;
	return 0;
}

int main()
{
	const int size{ 8 };
	int vector[size] = { 0 };
	zapolnenie(size, vector);
	return 0;
}