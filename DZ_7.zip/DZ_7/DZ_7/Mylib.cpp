#include <iostream>
using namespace std;

namespace MeinLeiben {
	bool print(size_t size, float* ptr)   // ����� �������
	{
		for (size_t i = 0; i < size; i++)
		{
			cout << ptr[i] << "  ";
		}
		cout << endl;
		return true;
	}

	bool podc4et(size_t size, float* ptr) // ������� + � - �����
	{

		print(size, ptr);
		int k = 0;
		int m = 0;
		for (int i = 0; i < size; i++)
		{
			if (ptr[i] > 0)
			{
				k = k + 1;
			}
			else
				m = m + 1;
		}
		cout << "+ digit: " << k;
		cout << endl;
		cout << "- digit: " << m;
		return true;
	}
	bool arrayInput(size_t size,int* ptr2)
	{
		
		for (int i = 0; i < size; i++)
		{
			cout << "[" << i << "]" << "-";
			cin >> ptr2[i];
		}
		cout << "array is:   " << endl;
		for (int i = 0; i < size; i++)
		{
			cout << ptr2[i] << "   ";
		}
		cout << endl;
	return true;
	}

	bool sort(size_t size, int* ptr2)
	{
		arrayInput(size, ptr2);
		for (int i = 0; i < size; i++)
		{
			for (int k = 0; k < size-1; k++)
			{
				if (ptr2[i] > ptr2[i + 1])
				{
					int x = ptr2[i];
					ptr2[i] = ptr2[i + 1];
					ptr2[i + 1] = x;
					cout << ptr2[i];
				}
			}
		}
			
		return true;
	}
};