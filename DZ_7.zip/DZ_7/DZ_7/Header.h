#pragma once
namespace MeinLeiben {
	bool print(size_t size, float* ptr);
	bool podc4et(size_t size, float* ptr);
	bool arrayInput(size_t size, int* ptr2);
	bool sort(size_t size, int* ptr2);
}
