﻿// DZ_5.cpp - задача-2 : 

#include <iostream>
/*Задача 2. _Задать целочисленный массив, состоящий из элементов 0 и 1.
Например: [1, 1, 0, 0, 1, 0, 1, 1, 0, 0] .Написать функцию, 
заменяющую в принятом массиве 0 на 1, 1 на 0. 
Выводить на экран массив до изменений и после.
*/
using namespace std;
bool zamena(int size, int *ptr)
{
	
	for (int i = 0; i < size; i++)
	{
		
		switch (ptr[i]) {
		case (0):
			ptr[i] = 1;
			break;
		case (1):
			ptr[i] = 0;
			break;

						}
			


		cout << "New vector is  " << ptr[i] << endl;
	}
	cout << endl;
	return true;
}

int main()
{
	const int size{ 10 };
	int vector[size] = {0,0,0,0,1,1,1,1,1,0};
	for (int i = 0; i < size; i++)
	{
		cout << "OLD vector is  " << vector[i] << endl;
		cout << endl;
	}
	zamena(size, vector);
	return 0;
}