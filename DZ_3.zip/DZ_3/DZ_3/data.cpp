extern const int a {2};
extern const int b{ 2 };
extern const int c{ 4 };
extern const int d{ 6 };